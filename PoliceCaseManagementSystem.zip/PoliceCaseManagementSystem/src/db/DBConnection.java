/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * <h2>Utility class for establishing JDBC connections to the crime management database.</h2>
 *
 * <p>Provides a static factory method {@link #getConnection()} to obtain a {@link Connection}
 * to MySQL. Uses the MySQL Connector/J driver (com.mysql.cj.jdbc.Driver).</p>
 *
 * <p><strong>Warning:</strong> This implementation uses <strong>hard-coded credentials</strong> and
 * creates a new connection on every call. It is suitable only for <strong>development or prototyping</strong>.</p>
 *
 * <p><strong>Production Recommendation:</strong> Replace with a connection pool such as
 * <a href="https://github.com/brettwooldridge/HikariCP">HikariCP</a> or Apache DBCP.
 * Externalize configuration via {@code .properties}, environment variables, or JNDI.</p>
 *
 * @author User
 * @version 1.0
 * @since 2025-11-06
 */
public class DBConnection {

    // ==================== DATABASE CONFIGURATION ====================
    // TODO: Move to external config (e.g., application.properties, env vars)
    private static final String URL = "jdbc:mysql://localhost:3306/crime_management"
                                   + "?useSSL=false"
                                   + "&serverTimezone=UTC"
                                   + "&allowPublicKeyRetrieval=true"
                                   + "&useUnicode=true"
                                   + "&characterEncoding=UTF-8";

    private static final String USER = "root";           // Change in production!
    private static final String PASS = "";               // NEVER commit real passwords!

    // Optional: Enable for debug only
    private static final boolean DEBUG = true;

    /**
     * Returns a new JDBC {@link Connection} to the crime_management database.
     *
     * <p>Loads the MySQL driver explicitly and uses {@link DriverManager} to connect.</p>
     *
     * @return a valid {@link Connection} object
     * @throws SQLException if a database access error occurs or the driver is not found
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Explicit driver load helps catch missing JAR early
            Class.forName("com.mysql.cj.jdbc.Driver");

            if (DEBUG) {
                System.out.println("MySQL Driver loaded successfully!");
                System.out.println("Connecting to: " + URL);
            }

            Connection conn = DriverManager.getConnection(URL, USER, PASS);

            if (DEBUG) {
                System.out.println("Database connection established.");
            }

            return conn;

        } catch (ClassNotFoundException e) {
            // Specific message to help developers add the correct JAR
            throw new SQLException(
                "MySQL JDBC Driver not found! "
              + "Add 'mysql-connector-j-8.x.jar' (or newer) to your project libraries. "
              + "Download from: https://dev.mysql.com/downloads/connector/j/",
                e
            );
        } catch (SQLException e) {
            // Wrap with context but preserve stack trace
            throw new SQLException("Failed to connect to database: " + e.getMessage(), e);
        }
    }

    // Prevent instantiation
    private DBConnection() {
        throw new UnsupportedOperationException("Utility class - do not instantiate");
    }

    // ==================== FUTURE ENHANCEMENTS ====================
    /*
     * TODO: Replace with HikariCP or similar connection pool
     * TODO: Load config from application.properties or environment variables
     * TODO: Add connection validation (conn.isValid(2))
     * TODO: Support connection timeouts and retry logic
     * TODO: Remove System.out logging → use SLF4J/Log4j
     * TODO: Add SSL support for production
     */
}