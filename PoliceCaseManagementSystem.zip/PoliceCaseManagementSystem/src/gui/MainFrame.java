package gui;

import dao.CaseDAO;
import dao.OfficerDAO;
import model.Case;
import model.Officer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

public class MainFrame extends JFrame {

    // Components
    private JTabbedPane tabbedPane;
    private JPanel officerPanel, casePanel;
    private JTable officerTable, caseTable;
    private DefaultTableModel officerModel, caseModel;
    private final OfficerDAO officerDAO = new OfficerDAO();
    private final CaseDAO caseDAO = new CaseDAO();

    // Case tab fields
    private JTextField txtDetails, txtLocation, txtDate;
    private JComboBox<String> cmbOfficer, cmbCategory, cmbStatus;

    public MainFrame() {
        setTitle("Stemsview Police Case Management System");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();
        createOfficerTab();
        createCaseTab();
        add(tabbedPane);
        setVisible(true);
    }

    // ====================== OFFICER TAB ======================
    private void createOfficerTab() {
        officerPanel = new JPanel(new BorderLayout());
        JPanel input = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField txtFirst = new JTextField(), txtLast = new JTextField();
        JTextField txtRank = new JTextField(), txtPhone = new JTextField();

        input.add(new JLabel("First Name:")); input.add(txtFirst);
        input.add(new JLabel("Last Name:")); input.add(txtLast);
        input.add(new JLabel("Rank:")); input.add(txtRank);
        input.add(new JLabel("Phone:")); input.add(txtPhone);

        JPanel buttons = new JPanel();
        JButton btnAdd = new JButton("Add Officer");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        buttons.add(btnAdd); buttons.add(btnUpdate); buttons.add(btnDelete);

        officerModel = new DefaultTableModel(new String[]{"ID", "First", "Last", "Rank", "Phone"}, 0);
        officerTable = new JTable(officerModel);
        JScrollPane scroll = new JScrollPane(officerTable);

        officerPanel.add(input, BorderLayout.NORTH);
        officerPanel.add(scroll, BorderLayout.CENTER);
        officerPanel.add(buttons, BorderLayout.SOUTH);
        tabbedPane.addTab("Officers", officerPanel);

        // Add Officer
        btnAdd.addActionListener(e -> {
            try {
                Officer o = new Officer(0, txtFirst.getText().trim(), txtLast.getText().trim(),
                        txtRank.getText().trim(), txtPhone.getText().trim());
                officerDAO.insertOfficer(o);
                refreshOfficerTable();
                clearOfficerFields(txtFirst, txtLast, txtRank, txtPhone);
                refreshCaseComboBoxes(); // Refresh Cases tab
                JOptionPane.showMessageDialog(this, "Officer added.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Add failed: " + ex.getMessage());
            }
        });

        // Select row → fill fields
        officerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = officerTable.getSelectedRow();
                if (row >= 0) {
                    txtFirst.setText(officerModel.getValueAt(row, 1).toString());
                    txtLast.setText(officerModel.getValueAt(row, 2).toString());
                    txtRank.setText(officerModel.getValueAt(row, 3).toString());
                    txtPhone.setText(officerModel.getValueAt(row, 4).toString());
                }
            }
        });

        // Update
        btnUpdate.addActionListener(e -> {
            int row = officerTable.getSelectedRow();
            if (row >= 0) {
                try {
                    int id = (int) officerModel.getValueAt(row, 0);
                    Officer o = new Officer(id, txtFirst.getText().trim(), txtLast.getText().trim(),
                            txtRank.getText().trim(), txtPhone.getText().trim());
                    officerDAO.updateOfficer(o);
                    refreshOfficerTable();
                    clearOfficerFields(txtFirst, txtLast, txtRank, txtPhone);
                    refreshCaseComboBoxes();
                    JOptionPane.showMessageDialog(this, "Officer updated.");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Update failed: " + ex.getMessage());
                }
            }
        });

        // Delete
        btnDelete.addActionListener(e -> {
            int row = officerTable.getSelectedRow();
            if (row >= 0) {
                int id = (int) officerModel.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(this, "Delete officer ID " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        officerDAO.deleteOfficer(id);
                        refreshOfficerTable();
                        refreshCaseComboBoxes();
                        JOptionPane.showMessageDialog(this, "Officer deleted.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Delete failed: " + ex.getMessage());
                    }
                }
            }
        });

        refreshOfficerTable();
    }

    private void clearOfficerFields(JTextField... fields) {
        for (JTextField f : fields) f.setText("");
    }

    private void refreshOfficerTable() {
        try {
            officerModel.setRowCount(0);
            List<Officer> list = officerDAO.getAllOfficers();
            for (Officer o : list) {
                officerModel.addRow(new Object[]{
                        o.getOfficerID(), o.getFirstName(), o.getLastName(), o.getRank(), o.getPhone()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ====================== CASE TAB ======================
    private void createCaseTab() {
        casePanel = new JPanel(new BorderLayout());
        JPanel input = new JPanel(new GridLayout(7, 2, 10, 10));
        txtDetails = new JTextField();
        cmbOfficer = new JComboBox<>();
        cmbCategory = new JComboBox<>();
        txtLocation = new JTextField();
        txtDate = new JTextField();
        cmbStatus = new JComboBox<>();

        input.add(new JLabel("Details:")); input.add(txtDetails);
        input.add(new JLabel("Officer:")); input.add(cmbOfficer);
        input.add(new JLabel("Category:")); input.add(cmbCategory);
        input.add(new JLabel("Location:")); input.add(txtLocation);
        input.add(new JLabel("Reported On (yyyy-MM-dd):")); input.add(txtDate);
        input.add(new JLabel("Status:")); input.add(cmbStatus);

        JPanel buttons = new JPanel();
        JButton btnAdd = new JButton("Add Case");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        buttons.add(btnAdd); buttons.add(btnUpdate); buttons.add(btnDelete);

        caseModel = new DefaultTableModel(new String[]{
                "ID", "Details", "Officer ID", "Category", "Location", "Reported On", "Status"
        }, 0);
        caseTable = new JTable(caseModel);
        JScrollPane scroll = new JScrollPane(caseTable);

        casePanel.add(input, BorderLayout.NORTH);
        casePanel.add(scroll, BorderLayout.CENTER);
        casePanel.add(buttons, BorderLayout.SOUTH);
        tabbedPane.addTab("Cases", casePanel);

        loadCaseComboBoxes();

        // Add Case
        btnAdd.addActionListener(e -> {
            try {
                Case c = createCaseFromFields(0);
                if (c == null) return;
                caseDAO.insertCase(c);
                refreshCaseTable();
                clearCaseFields();
                JOptionPane.showMessageDialog(this, "Case added successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to add case: " + ex.getMessage());
            }
        });

        // Select row → fill fields
        caseTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = caseTable.getSelectedRow();
                if (row >= 0) {
                    txtDetails.setText(caseModel.getValueAt(row, 1).toString());
                    String officerId = caseModel.getValueAt(row, 2).toString();
                    String category = caseModel.getValueAt(row, 3).toString();
                    txtLocation.setText(caseModel.getValueAt(row, 4).toString());
                    txtDate.setText(caseModel.getValueAt(row, 5).toString());
                    String status = caseModel.getValueAt(row, 6).toString();

                    selectComboItem(cmbOfficer, officerId);
                    selectComboItem(cmbCategory, category);
                    selectComboItem(cmbStatus, status);
                }
            }
        });

        // Update
        btnUpdate.addActionListener(e -> {
            int row = caseTable.getSelectedRow();
            if (row >= 0) {
                try {
                    int id = (int) caseModel.getValueAt(row, 0);
                    Case c = createCaseFromFields(id);
                    if (c == null) return;
                    caseDAO.updateCase(c);
                    refreshCaseTable();
                    clearCaseFields();
                    JOptionPane.showMessageDialog(this, "Case updated!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Update failed: " + ex.getMessage());
                }
            }
        });

        // Delete
        btnDelete.addActionListener(e -> {
            int row = caseTable.getSelectedRow();
            if (row >= 0) {
                int id = (int) caseModel.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(this, "Delete case ID " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        caseDAO.deleteCase(id);
                        refreshCaseTable();
                        JOptionPane.showMessageDialog(this, "Case deleted.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Delete failed: " + ex.getMessage());
                    }
                }
            }
        });

        refreshCaseTable();
    }

    // Load combo boxes
    private void loadCaseComboBoxes() {
        try {
            // Officers
            cmbOfficer.removeAllItems();
            List<Officer> officers = officerDAO.getAllOfficers();
            if (officers.isEmpty()) {
                cmbOfficer.addItem("No officers - Add in Officers tab first");
            } else {
                for (Officer o : officers) {
                    cmbOfficer.addItem(o.getOfficerID() + " - " + o.getFirstName() + " " + o.getLastName());
                }
            }

            // Categories
            cmbCategory.removeAllItems();
            Map<String, String> cats = caseDAO.getCategories();
            for (Map.Entry<String, String> e : cats.entrySet()) {
                cmbCategory.addItem(e.getKey() + " - " + e.getValue());
            }

            // Statuses
            cmbStatus.removeAllItems();
            Map<Integer, String> stats = caseDAO.getStatuses();
            for (Map.Entry<Integer, String> e : stats.entrySet()) {
                cmbStatus.addItem(e.getKey() + " - " + e.getValue());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    // Safe combo selection
    private void selectComboItem(JComboBox<String> combo, String key) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            String item = combo.getItemAt(i);
            if (item.startsWith(key + " -")) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    // Create case with validation
    private Case createCaseFromFields(int caseID) {
        try {
            String details = txtDetails.getText().trim();
            if (details.isEmpty()) throw new IllegalArgumentException("Case details required.");

            String officerStr = (String) cmbOfficer.getSelectedItem();
            if (officerStr == null || officerStr.contains("No officers")) {
                throw new IllegalArgumentException("No officer selected. Add officer first.");
            }
            int officerId = Integer.parseInt(officerStr.split(" - ")[0]);

            String catStr = (String) cmbCategory.getSelectedItem();
            String category = catStr.split(" - ")[0];

            String location = txtLocation.getText().trim();

            String dateStr = txtDate.getText().trim();
            if (!dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
                throw new IllegalArgumentException("Date must be yyyy-MM-dd");
            }
            java.sql.Date reportedOn = java.sql.Date.valueOf(dateStr);

            String statusStr = (String) cmbStatus.getSelectedItem();
            int status = Integer.parseInt(statusStr.split(" - ")[0]);

            return new Case(caseID, details, officerId, category, location, reportedOn, status);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input: " + ex.getMessage());
            return null;
        }
    }

    private void clearCaseFields() {
        txtDetails.setText("");
        txtLocation.setText("");
        txtDate.setText("");
        if (cmbOfficer.getItemCount() > 0) cmbOfficer.setSelectedIndex(0);
        if (cmbCategory.getItemCount() > 0) cmbCategory.setSelectedIndex(0);
        if (cmbStatus.getItemCount() > 0) cmbStatus.setSelectedIndex(0);
    }

    private void refreshCaseTable() {
        try {
            caseModel.setRowCount(0);
            List<Case> list = caseDAO.getAllCases();
            for (Case c : list) {
                caseModel.addRow(new Object[]{
                        c.getCaseID(), c.getCaseDetails(), c.getAttendingOfficer(),
                        c.getCategory(), c.getLocation(), c.getReportedOn(), c.getStatus()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Public method to refresh combo boxes from Officer tab
    public void refreshCaseComboBoxes() {
        loadCaseComboBoxes();
    }

    // ====================== MAIN ======================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}