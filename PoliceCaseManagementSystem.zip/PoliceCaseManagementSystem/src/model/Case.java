/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;
import java.util.Objects;

/**
 * <h2>Domain model representing a crime case in the Stemsview Police Case Management System.</h2>
 *
 * <p>Maps directly to the <code>CASE_TABLE</code> in the database:
 * <ul>
 *   <li><code>CaseID</code> - Primary key (auto-generated)</li>
 *   <li><code>CaseDetails</code> - Full description of the incident</li>
 *   <li><code>AttendingOfficer</code> - Foreign key to <code>OFFICER.OfficerID</code></li>
 *   <li><code>Category</code> - Foreign key to <code>Crime_Category.CrimeTypeID</code></li>
 *   <li><code>Location</code> - Where the incident occurred</li>
 *   <li><code>ReportedOn</code> - Date the case was reported</li>
 *   <li><code>Status</code> - Foreign key to <code>Case_Status.StatusCode</code></li>
 * </ul>
 * </p>
 *
 * <p>All setters include basic validation. Null checks and business rules
 * are enforced to prevent invalid state.</p>
 *
 * @author User
 * @version 1.0
 * @since 2025-11-06
 */
public class Case {

    private int caseID;
    private String caseDetails;
    private int attendingOfficer;
    private String category;
    private String location;
    private Date reportedOn;
    private int status;

    /**
     * Constructs a new Case instance.
     *
     * @param caseID          the unique identifier (0 for new cases)
     * @param caseDetails    the incident description (must not be null or empty)
     * @param attendingOfficer the officer ID assigned (must be > 0)
     * @param category        the crime category ID (must not be null or empty)
     * @param location        the incident location (must not be null or empty)
     * @param reportedOn      the report date (must not be null)
     * @param status          the case status code (must be >= 0)
     * @throws IllegalArgumentException if any validation fails
     */
    public Case(int caseID, String caseDetails, int attendingOfficer, String category,
                String location, Date reportedOn, int status) {
        setCaseID(caseID);
        setCaseDetails(caseDetails);
        setAttendingOfficer(attendingOfficer);
        setCategory(category);
        setLocation(location);
        setReportedOn(reportedOn);
        setStatus(status);
    }

    // ==================== GETTERS ====================

    public int getCaseID() {
        return caseID;
    }

    public String getCaseDetails() {
        return caseDetails;
    }

    public int getAttendingOfficer() {
        return attendingOfficer;
    }

    public String getCategory() {
        return category;
    }

    public String getLocation() {
        return location;
    }

    public Date getReportedOn() {
        return reportedOn;
    }

    public int getStatus() {
        return status;
    }

    // ==================== SETTERS WITH VALIDATION ====================

    /**
     * Sets the case ID. Used internally after insert.
     *
     * @param caseID must be >= 0
     */
    public void setCaseID(int caseID) {
        if (caseID < 0) {
            throw new IllegalArgumentException("CaseID cannot be negative");
        }
        this.caseID = caseID;
    }

    /**
     * Sets the case details.
     *
     * @param caseDetails must not be null or blank
     */
    public void setCaseDetails(String caseDetails) {
        if (caseDetails == null || caseDetails.trim().isEmpty()) {
            throw new IllegalArgumentException("Case details are required");
        }
        this.caseDetails = caseDetails.trim();
    }

    /**
     * Sets the attending officer ID.
     *
     * @param attendingOfficer must be > 0
     */
    public void setAttendingOfficer(int attendingOfficer) {
        if (attendingOfficer <= 0) {
            throw new IllegalArgumentException("Attending officer ID must be positive");
        }
        this.attendingOfficer = attendingOfficer;
    }

    /**
     * Sets the crime category.
     *
     * @param category must not be null or blank
     */
    public void setCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("Category is required");
        }
        this.category = category.trim();
    }

    /**
     * Sets the incident location.
     *
     * @param location must not be null or blank
     */
    public void setLocation(String location) {
        if (location == null || location.trim().isEmpty()) {
            throw new IllegalArgumentException("Location is required");
        }
        this.location = location.trim();
    }

    /**
     * Sets the reported date.
     *
     * @param reportedOn must not be null
     */
    public void setReportedOn(Date reportedOn) {
        this.reportedOn = Objects.requireNonNull(reportedOn, "Reported date cannot be null");
    }

    /**
     * Sets the case status code.
     *
     * @param status must be >= 0
     */
    public void setStatus(int status) {
        if (status < 0) {
            throw new IllegalArgumentException("Status code cannot be negative");
        }
        this.status = status;
    }

    // ==================== UTILITY METHODS ====================

    /**
     * Returns a concise string representation for UI display (e.g., combo boxes, lists).
     *
     * <p>Truncates long details to 30 characters and appends "..."</p>
     *
     * @return formatted string: "ID | Details..."
     */
    @Override
    public String toString() {
        String truncated = caseDetails.length() > 30
                ? caseDetails.substring(0, 30) + "..."
                : caseDetails;
        return caseID + " | " + truncated;
    }

    /**
     * Compares this case with another for equality.
     *
     * <p>Two cases are equal if their <code>caseID</code> matches.</p>
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Case)) return false;
        Case that = (Case) o;
        return caseID == that.caseID;
    }

    /**
     * Returns a hash code based on the case ID.
     */
    @Override
    public int hashCode() {
        return Objects.hash(caseID);
    }

    // ==================== FUTURE ENHANCEMENTS ====================
    /*
     * TODO: Add validation for max length (e.g., caseDetails <= 4000 chars)
     * TODO: Add isNew() method (caseID == 0)
     * TODO: Add copy constructor or builder pattern
     * TODO: Add formatted date string getter
     */
}