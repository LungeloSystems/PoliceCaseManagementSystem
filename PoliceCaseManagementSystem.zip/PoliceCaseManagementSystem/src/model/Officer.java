/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 * <h2>Domain model representing a police officer in the Stemsview Case Management System.</h2>
 *
 * <p>Maps directly to the <code>OFFICER</code> table:
 * <ul>
 *   <li><code>OfficerID</code> - Primary key (auto-generated)</li>
 *   <li><code>FirstName</code> - Officer's first name</li>
 *   <li><code>LastName</code> - Officer's last name</li>
 *   <li><code>Rank</code> - Police rank (e.g., Constable, Sergeant)</li>
 *   <li><code>Phone</code> - Contact phone number</li>
 * </ul>
 * </p>
 *
 * <p>All setters perform validation to prevent invalid state.
 * Null values and empty strings are rejected for required fields.</p>
 *
 * @author User
 * @version 1.0
 * @since 2025-11-06
 */
public class Officer {

    private int officerID;
    private String firstName;
    private String lastName;
    private String rank;
    private String phone;

    /**
     * Constructs a new Officer instance.
     *
     * @param officerID  the unique identifier (0 for new officers)
     * @param firstName  the officer's first name (required)
     * @param lastName   the officer's last name (required)
     * @param rank       the police rank (required)
     * @param phone      the contact phone number (required)
     * @throws IllegalArgumentException if any validation fails
     */
    public Officer(int officerID, String firstName, String lastName, String rank, String phone) {
        setOfficerID(officerID);
        setFirstName(firstName);
        setLastName(lastName);
        setRank(rank);
        setPhone(phone);
    }

    // ==================== GETTERS ====================

    public int getOfficerID() {
        return officerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getRank() {
        return rank;
    }

    public String getPhone() {
        return phone;
    }

    // ==================== SETTERS WITH VALIDATION ====================

    /**
     * Sets the officer ID. Used after database insert.
     *
     * @param officerID must be >= 0
     */
    public void setOfficerID(int officerID) {
        if (officerID < 0) {
            throw new IllegalArgumentException("OfficerID cannot be negative");
        }
        this.officerID = officerID;
    }

    /**
     * Sets the first name.
     *
     * @param firstName must not be null or blank
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.trim().isEmpty()) {
            throw new IllegalArgumentException("First name is required");
        }
        this.firstName = firstName.trim();
    }

    /**
     * Sets the last name.
     *
     * @param lastName must not be null or blank
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.trim().isEmpty()) {
            throw new IllegalArgumentException("Last name is required");
        }
        this.lastName = lastName.trim();
    }

    /**
     * Sets the police rank.
     *
     * @param rank must not be null or blank
     */
    public void setRank(String rank) {
        if (rank == null || rank.trim().isEmpty()) {
            throw new IllegalArgumentException("Rank is required");
        }
        this.rank = rank.trim();
    }

    /**
     * Sets the phone number.
     *
     * @param phone must not be null or blank
     */
    public void setPhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number is required");
        }
        this.phone = phone.trim();
    }

    // ==================== UTILITY METHODS ====================

    /**
     * Returns a user-friendly string for display in UI components.
     *
     * <p>Format: <code>ID | First Last (Rank)</code></p>
     *
     * @return formatted officer summary
     */
    @Override
    public String toString() {
        return officerID + " | " + firstName + " " + lastName + " (" + rank + ")";
    }

    /**
     * Two officers are equal if their <code>officerID</code> matches.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Officer)) return false;
        Officer that = (Officer) o;
        return officerID == that.officerID;
    }

    /**
     * Hash code based on <code>officerID</code>.
     */
    @Override
    public int hashCode() {
        return Objects.hash(officerID);
    }

    // ==================== FUTURE ENHANCEMENTS ====================
    /*
     * TODO: Add phone number format validation (e.g., regex for ZA numbers)
     * TODO: Add fullName() method
     * TODO: Add isActive flag
     * TODO: Add builder pattern for complex object creation
     */
}