/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.DBConnection;
import model.Case;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <h2>Data Access Object (DAO) for managing Case entities in the database.</h2>
 * 
 * <p>This class provides CRUD operations and lookup methods for cases, categories, and statuses.
 * It uses {@link DBConnection} for database connectivity and follows JDBC best practices
 * such as using {@link PreparedStatement} to prevent SQL injection and try-with-resources
 * for automatic resource cleanup.</p>
 * 
 * <p><strong>Thread Safety:</strong> Not guaranteed. Consider connection pooling (e.g., HikariCP)
 * in production environments.</p>
 * 
 * @author User
 * @version 1.0
 * @since 2025-11-06
 */
public class CaseDAO {

    /**
     * Inserts a new case record into the CASE_TABLE.
     * 
     * @param c the {@link Case} object containing case details (must not be null)
     * @throws SQLException if a database access error occurs or the insert fails
     * @throws IllegalArgumentException if the Case object is null or has invalid data
     */
    public void insertCase(Case c) throws SQLException {
        if (c == null) {
            throw new IllegalArgumentException("Case object cannot be null");
        }

        // SQL uses parameterized query to prevent SQL injection
        String sql = "INSERT INTO CASE_TABLE (CaseDetails, AttendingOfficer, Category, Location, ReportedOn, Status) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        // try-with-resources ensures Connection and PreparedStatement are closed automatically
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Set parameters in order matching the SQL
            pstmt.setString(1, c.getCaseDetails());
            pstmt.setInt(2, c.getAttendingOfficer());     // TODO: Validate officer exists in Officer table?
            pstmt.setString(3, c.getCategory());          // Category should match CrimeTypeID in Crime_Category
            pstmt.setString(4, c.getLocation());
            pstmt.setDate(5, c.getReportedOn());          // java.sql.Date expected
            pstmt.setInt(6, c.getStatus());               // Status should match StatusCode in Case_Status

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Insert failed: No rows affected.");
            }
        } catch (SQLException e) {
            // Wrap and rethrow with context for better debugging
            throw new SQLException("Error inserting case: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves all cases from the database.
     * 
     * @return a {@link List} of {@link Case} objects, never null (empty list if no records)
     * @throws SQLException if a database access error occurs
     */
    public List<Case> getAllCases() throws SQLException {
        List<Case> cases = new ArrayList<>();
        
        // Select all fields needed to reconstruct Case object
        String sql = "SELECT c.CaseID, c.CaseDetails, c.AttendingOfficer, c.Category, "
                   + "c.Location, c.ReportedOn, c.Status "
                   + "FROM CASE_TABLE c "
                   + "ORDER BY c.ReportedOn DESC"; // Optional: order by most recent

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Case caseObj = new Case(
                    rs.getInt("CaseID"),
                    rs.getString("CaseDetails"),
                    rs.getInt("AttendingOfficer"),
                    rs.getString("Category"),
                    rs.getString("Location"),
                    rs.getDate("ReportedOn"),
                    rs.getInt("Status")
                );
                cases.add(caseObj);
            }
        } catch (SQLException e) {
            throw new SQLException("Error retrieving cases: " + e.getMessage(), e);
        }
        
        return cases;
    }

    /**
     * Updates an existing case in the database.
     * 
     * @param c the {@link Case} object with updated values; CaseID must be valid and exist
     * @throws SQLException if update fails or CaseID is not found
     */
    public void updateCase(Case c) throws SQLException {
        if (c == null || c.getCaseID() <= 0) {
            throw new IllegalArgumentException("Valid Case with positive CaseID required for update");
        }

        String sql = "UPDATE CASE_TABLE SET CaseDetails = ?, AttendingOfficer = ?, Category = ?, "
                   + "Location = ?, ReportedOn = ?, Status = ? WHERE CaseID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, c.getCaseDetails());
            pstmt.setInt(2, c.getAttendingOfficer());
            pstmt.setString(3, c.getCategory());
            pstmt.setString(4, c.getLocation());
            pstmt.setDate(5, c.getReportedOn());
            pstmt.setInt(6, c.getStatus());
            pstmt.setInt(7, c.getCaseID());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Update failed: CaseID " + c.getCaseID() + " not found.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error updating case: " + e.getMessage(), e);
        }
    }

    /**
     * Deletes a case by its CaseID.
     * 
     * @param caseID the primary key of the case to delete
     * @throws SQLException if deletion fails or case is not found
     */
    public void deleteCase(int caseID) throws SQLException {
        if (caseID <= 0) {
            throw new IllegalArgumentException("CaseID must be positive");
        }

        String sql = "DELETE FROM CASE_TABLE WHERE CaseID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, caseID);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SQLException("Delete failed: CaseID " + caseID + " not found.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error deleting case: " + e.getMessage(), e);
        }
    }

    // ==================== LOOKUP METHODS FOR UI COMBOBOXES ====================

    /**
     * Retrieves all crime categories for populating dropdowns.
     * 
     * @return a {@link Map} where key = CrimeTypeID (String), value = Description
     * @throws SQLException if query fails
     */
    public Map<String, String> getCategories() throws SQLException {
        Map<String, String> cats = new HashMap<>();
        
        String sql = "SELECT CrimeTypeID, Description FROM Crime_Category ORDER BY Description";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String id = rs.getString("CrimeTypeID");
                String desc = rs.getString("Description");
                cats.put(id, desc);
            }
        } catch (SQLException e) {
            throw new SQLException("Error loading crime categories: " + e.getMessage(), e);
        }
        
        return cats;
    }

    /**
     * Retrieves all case statuses for populating status dropdowns.
     * 
     * @return a {@link Map} where key = StatusCode (Integer), value = StatusDescription
     * @throws SQLException if query fails
     */
    public Map<Integer, String> getStatuses() throws SQLException {
        Map<Integer, String> stats = new HashMap<>();
        
        String sql = "SELECT StatusCode, StatusDescription FROM Case_Status ORDER BY StatusCode";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int code = rs.getInt("StatusCode");
                String desc = rs.getString("StatusDescription");
                stats.put(code, desc);
            }
        } catch (SQLException e) {
            throw new SQLException("Error loading case statuses: " + e.getMessage(), e);
        }
        
        return stats;
    }

    // ==================== FUTURE ENHANCEMENTS ====================
    /*
     * TODO: Add getCaseById(int caseID) method
     * TODO: Add searchCases(String keyword, String category, Date from, Date to)
     * TODO: Validate foreign keys (AttendingOfficer, Category) before insert/update
     * TODO: Use connection pooling in production
     * TODO: Add logging (SLF4J) instead of throwing raw exceptions
     */
}