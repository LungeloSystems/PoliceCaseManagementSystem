/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.DBConnection;
import model.Officer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * <h2>Data Access Object (DAO) for {@link Officer} entities.</h2>
 *
 * <p>Provides CRUD operations for the <code>OFFICER</code> table.
 * All methods use {@link PreparedStatement} to avoid SQL injection and
 * try-with-resources to guarantee proper resource cleanup.</p>
 *
 * <p><strong>Thread safety:</strong> Not guaranteed. In production use a connection pool
 * (e.g., HikariCP) instead of {@link DBConnection#getConnection()}.</p>
 *
 * @author User
 * @version 1.0
 * @since 2025-11-06
 */
public class OfficerDAO {

    /**
     * Inserts a new officer record.
     *
     * @param officer the {@link Officer} object to insert (must not be null)
     * @throws SQLException if the insert fails or a database error occurs
     * @throws IllegalArgumentException if the officer argument is null
     */
    public void insertOfficer(Officer officer) throws SQLException {
        if (officer == null) {
            throw new IllegalArgumentException("Officer object cannot be null");
        }

        // Back-ticks around `Rank` because it is a reserved keyword in many SQL dialects
        String sql = "INSERT INTO OFFICER (FirstName, LastName, `Rank`, Phone) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, officer.getFirstName());
            pstmt.setString(2, officer.getLastName());
            pstmt.setString(3, officer.getRank());
            pstmt.setString(4, officer.getPhone());

            int rows = pstmt.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Insert failed: no rows affected");
            }
        } catch (SQLException e) {
            throw new SQLException("Error inserting officer: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves every officer from the database.
     *
     * @return a {@link List} of {@link Officer} objects (never null, empty if no rows)
     * @throws SQLException if the query fails
     */
    public List<Officer> getAllOfficers() throws SQLException {
        List<Officer> officers = new ArrayList<>();

        String sql = "SELECT OfficerID, FirstName, LastName, `Rank`, Phone "
                   + "FROM OFFICER "
                   + "ORDER BY LastName, FirstName";   // consistent UI ordering

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Officer o = new Officer(
                    rs.getInt("OfficerID"),
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("Rank"),
                    rs.getString("Phone")
                );
                officers.add(o);
            }
        } catch (SQLException e) {
            throw new SQLException("Error retrieving officers: " + e.getMessage(), e);
        }

        return officers;
    }

    /**
     * Updates an existing officer record.
     *
     * @param officer the {@link Officer} with updated values; {@code OfficerID} must be > 0
     * @throws SQLException if the update fails or the ID is not found
     * @throws IllegalArgumentException if the officer is null or has an invalid ID
     */
    public void updateOfficer(Officer officer) throws SQLException {
        if (officer == null || officer.getOfficerID() <= 0) {
            throw new IllegalArgumentException("Valid Officer with positive OfficerID required");
        }

        String sql = "UPDATE OFFICER SET FirstName = ?, LastName = ?, `Rank` = ?, Phone = ? "
                   + "WHERE OfficerID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, officer.getFirstName());
            pstmt.setString(2, officer.getLastName());
            pstmt.setString(3, officer.getRank());
            pstmt.setString(4, officer.getPhone());
            pstmt.setInt(5, officer.getOfficerID());

            int rows = pstmt.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Update failed: OfficerID " + officer.getOfficerID() + " not found");
            }
        } catch (SQLException e) {
            throw new SQLException("Error updating officer: " + e.getMessage(), e);
        }
    }

    /**
     * Deletes an officer by primary key.
     *
     * @param officerID the ID of the officer to delete
     * @throws SQLException if the deletion fails or the ID is not found
     * @throws IllegalArgumentException if the ID is not positive
     */
    public void deleteOfficer(int officerID) throws SQLException {
        if (officerID <= 0) {
            throw new IllegalArgumentException("OfficerID must be positive");
        }

        String sql = "DELETE FROM OFFICER WHERE OfficerID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, officerID);
            int rows = pstmt.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Delete failed: OfficerID " + officerID + " not found");
            }
        } catch (SQLException e) {
            throw new SQLException("Error deleting officer: " + e.getMessage(), e);
        }
    }

    // ==================== FUTURE ENHANCEMENTS ====================
    /*
     * TODO: getOfficerById(int officerID)
     * TODO: searchOfficers(String keyword, String rank)
     * TODO: Validate phone format / uniqueness before insert/update
     * TODO: Return generated OfficerID after insert (use RETURN_GENERATED_KEYS)
     * TODO: Add SLF4J logging instead of raw exception messages
     */
}